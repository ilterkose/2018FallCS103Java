
public class outputMethod {

	public static void main(String[] args) {
		  int i=1;
		   int  x=100;
		   double y=0.42;
		   String name="Marya";
		  tryPrimitives(i,x,y,name);
		  System.out.println(" i = " + i+ " x = " +x+ " y = "+y+ " name = "+ name);

	}
	public static void tryPrimitives (int i, int b, double y, String text)
	{
	  i=i*10;
	  b=b-10;
	  y=0.45;
	  text="Sam";
	}

}
