import java.util.*;
public class Question4 {

	public static void main(String[] args) {
	System.out.println("Enter a: ");
	Scanner myscanner = new Scanner(System.in);
	int a = myscanner.nextInt();
	System.out.println("Enter b: ");
	int b = myscanner.nextInt();
	for (int i=a; i <= b; i++){
		if (i % 2 == 0 ){
			System.out.println(i); 
}         		
		}
	}
     }
