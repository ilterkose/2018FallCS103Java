
public class Assignment3_Base {

    public static void main(String[] args) {
        double gaussianResult = calculateGaussian(1, 1, 1);
        System.out.println(gaussianResult);
        int extractedNumber = extractNumber("Number of students in class A: 123");
        System.out.println(extractedNumber);
        int biggerNumber = compareNumbers("Number of students in class B: 45", "Number of students in class C: 63");
        System.out.println(biggerNumber);
        String s = "Take me home right now";
        for (int i = 0; i < s.length(); i++)
            System.out.println(moveToIndex(s, "home", i));
    	evaluateString("T&!F|T&!F");
    }

    // Q1
    public static double calculateGaussian(double x, double mean, double stddev) {
        /**
         * @params x, mean (μ), stddev (σ)
         * @return Result of Gaussian Formula given x, μ and σ
         */
	double result;

        return result;
    }

    // Q2 (a)
    public static int extractNumber(String text) {
        /**
         * @param text, a formatted String that contains number after : character
         * @return extracted number from String
         */
	int number;

        return number;
    }

    // Q2 (b)
    public static int compareNumbers(String s1, String s2) {
        /**
         * @params t1, t2 -> two formatted Strings that contain number after : character
         * @return bigger number that is extracted from Strings
         */
	int number;
        return number;
    }

    // Q3
    public static String moveToIndex(String text, String keyword, int index) {
        /**
         * @params text, keyword, index
         * @return bigger number that is extracted from Strings
         */
	String	modifiedText;
        return modifiedText;
    }

    // Q4
    public static char flip(char a) {
        /**
         * @param char a -> 'T' or 'F' character
         * @return return the negated value. i.e. flip('T') returns 'F'
         */

    }

    public static String replaceCharAt(String s, int pos, String c) {
        /**
         * @params string, position, character
         * @return modified version of S, that contains char C at index Pos
         */
	String	result;

        return result;
    }

    public static boolean char2bool(char c) {
        /**
         * @param char C -> 'T' or 'F'
         * @return boolean value of the char. T -> true, F -> false
         */
	boolean result;

        return result;
    }

    public static char bool2char(boolean b) {
        /**
         * @param boolean b -> true or false
         * @return char representation of boolean value of the char. true -> 'T', false -> 'F'
         */
	char result;

        return result;
    }

    public static boolean evaluateString(String s) {
        /**
         * @param String s -> Representing a logical expression i.e. "T&!F|T&!F"
         * @return truth value of the expression
         */

        System.out.println(s); // Print the original expression
        // We should handle operations in following order ! > & > |
        // Handle negations (!) first
        for (int i = 0; i < s.length() - 1; i++) {
            if (s.charAt(i) == '!') {
                // Handle negation here
            }
        }
        // We are done with negations. Remove all ! signs from String below
        System.out.println(s); // Print the modified expression (! Negation operations handled)

        // Now we should handle AND(&) operations
        int i = 0;
        while (i < s.length() - 2) {
            char a = s.charAt(i);
            char b = s.charAt(i + 1);
            char c = s.charAt(i + 2);
            if (b == '&') {
                // Handle AND operation here

            }
            i++;
        }
         System.out.println(s);	// Print the modified expression (& AND operations handled)

        // Finally we can handle OR(|) operations now
        i = 0;
        while (i < s.length() - 2) {
            char a = s.charAt(i);
            char b = s.charAt(i + 1);
            char c = s.charAt(i + 2);
            if (b == '|') {
                // Handle OR Operation here
            }
            i++;
        }
	System.out.println(s); // Print the final result (| OR operations handled)

	boolean	result;

        return result;
    }

}
