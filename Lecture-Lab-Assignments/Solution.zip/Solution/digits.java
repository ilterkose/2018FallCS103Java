package assg1;

public class digits {


	
	public static void main(String[] args) {
		//zero
		h_line();
		duple_line();
		duple_line();
		h_line();
		//four
		System.out.print("\n");
		duple_line();
		h_line();
		v_line_r();
		//five
		System.out.print("\n");
		h_line();
		v_line_l();
		h_line();
		v_line_r();
		h_line();
		//six
		System.out.print("\n");
		h_line();
		v_line_r();
		h_line();
		duple_line();
		h_line();
		//eight
		System.out.print("\n");
		h_line();
		duple_line();
		h_line();
		duple_line();
		h_line();
		//nine
		System.out.print("\n");
		h_line();
		duple_line();
		h_line();
		v_line_r();
		h_line();
	}
	
	public static void v_line_r() {		
		System.out.println("        ||");
		System.out.println("        ||");
		System.out.println("        ||");
		System.out.println("        ||");		
		System.out.println("        ||");
	
	}

	public static void v_line_l() {		
		System.out.println("||");
		System.out.println("||");
		System.out.println("||");
		System.out.println("||");		
		System.out.println("||");
	
	}
	
	
	public static void duple_line() {		
		System.out.println("||      ||");
		System.out.println("||      ||");
		System.out.println("||      ||");
		System.out.println("||      ||");		
		System.out.println("||      ||");
	
	}	
		

	public static void h_line() {		
		System.out.println("||||||||||");	
	}
}
