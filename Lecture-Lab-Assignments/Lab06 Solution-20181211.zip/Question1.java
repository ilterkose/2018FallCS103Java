import java.util.*;
public class Question1 {
	public static void main(String args[])
	{
		Scanner console = new Scanner(System.in);
		System.out.println("Enter the integer value of X");
		int X=console.nextInt();
		System.out.println("Enter the Integer value of I");
		int Y=console.nextInt();
		console.close();
		
		int SumOfSquares=0;
		for (int i=X;i<=Y;i++)
		{
			//check if number is even
			if(i%2==0)
			{
				//then calculate its square and accumlate the result
				SumOfSquares=SumOfSquares+square(i);
			}
		}
		
		System.out.println("Sum of Squares of even numbers between "+X+" and "+Y+ " is "+SumOfSquares);
	}
	
	//Define square method
	public static int square(int x)
	{
		return x*x;
	}
	

}
