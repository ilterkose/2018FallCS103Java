import java.util.Scanner;

public class Part3 {

	public static void main(String[] args) {
		int balance = 0;

		Scanner console = new Scanner(System.in);
		System.out.println("Enter a bank account owner name: ");
		String bankAccountOwnerName = console.nextLine();

		System.out.println("Enter a bank account number: ");
		int bankAccount = console.nextInt();
		if (bankAccount == 1) {
			System.out.println("Enter money sent by your friend to your account: ");
			int increase = console.nextInt();
			System.out.println("Enter your electric bill: ");
			int decrease = console.nextInt();
			balance += increase;
			balance -= decrease;
		} else {
			System.out.println("Not a valid account.");
		}
		System.out.println("Name: " + bankAccountOwnerName + " , " + "balance: " + balance);
	}
}
