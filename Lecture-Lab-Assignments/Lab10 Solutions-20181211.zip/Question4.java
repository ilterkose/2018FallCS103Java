import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Question4 {

	public static void main(String[] args)  throws FileNotFoundException  {
		Scanner input = new Scanner(new File("grades.txt"));
		
		int sum=0;
		int cnt=0;
		
		while (input.hasNextInt()) {//check file end
			int grade=input.nextInt();
			sum+=grade;
			cnt++; //count students
		}
		input.close();
		double avg=(double) sum/cnt;
		System.out.println( "Total avearage  is: "+avg );
		
	}

}
