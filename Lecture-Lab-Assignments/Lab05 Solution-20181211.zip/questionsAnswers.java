import java.util.Scanner;

public class questionsAnswers {

	public static void main(String[] args) {
		 Scanner keyboard = new Scanner(System.in);
	
		
		          System.out.println( "Which city you are living in??" );
		          keyboard.next();
		  
		          System.out.println( "What is 10 multiply by 10??" );
		         keyboard.nextInt();
		 
		         System.out.println( "What is your favourite colour?" );
		         keyboard.next();
		 
		         System.out.println( "Enter a number between 0.1 and 0.9." );
	              keyboard.next();
	              keyboard.close(); // arbitrary
	              
	             
	            
		    
	              

	}

}
