public class October1Monday {
    public static void main(String[] args) // CS103 İLK DERS YAPILANLAR
    {
        System.out.println("\ta\tb\tc");
        System.out.println("\\\\");
        System.out.println("'");
        System.out.println("\"\"\"");
        System.out.println("C:\nin\the downward spiral");
    }
}
