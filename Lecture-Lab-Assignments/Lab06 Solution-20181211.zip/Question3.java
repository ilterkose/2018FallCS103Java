import java.util.*;
public class Question3 {

	public static void main(String[] args) {
	System.out.println("Enter your grade: ");
	Scanner myscanner = new Scanner(System.in);
	double grade = myscanner.nextDouble();
	    if (grade >= 60) {
	    	System.out.println("You passed the course"); 
	    } else {
              System.out.println("Unfortunately, you failed the course"); 
         		}          
	} 
}
