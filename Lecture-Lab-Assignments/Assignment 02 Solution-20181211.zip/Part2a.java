
public class Part2a {
	public static void main(String [] args) {
		printFirstLine(24);
		printSecondLine(20);
		printThirdLine();
		printSecondLine(20);
		printFirstLine(24);
	}
	
	public static void printFirstLine(int starCount) {
		for(int i = 0; i< starCount; i++) {
			System.out.print("*");
		}
		System.out.println();
	}
	
	public static void printSecondLine(int spaceCount) {
		System.out.print("**");
		for(int i = 0; i< 20; i++) {
			System.out.print(" ");
		}
		System.out.println("**");
	}
	
	public static void printThirdLine() {
		System.out.print("**");
		System.out.print(" JAVA & PROGRAMMING ");
		System.out.println("**");
	}
}
