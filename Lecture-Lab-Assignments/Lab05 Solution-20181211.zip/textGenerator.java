
public class textGenerator {

	public static void main(String[] args) {
		
	generator(" gift","accepting");
	generator(" mystery","solving");
	generator(" game","playing");
	generator(" chance ","taking ");
	generator("mission ","fulfilling");
	generator("love ","enjoying ");
	

	}
public static void generator(String s1, String s2)
    {
	
	System.out.println("Life is a "+s1+", I am "+s2+"it.");
    }
}
