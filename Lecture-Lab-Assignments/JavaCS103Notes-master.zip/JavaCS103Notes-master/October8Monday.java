public class October8Monday {
    public static void main(String[] args){
        /* double first_number, second_number, third_number;
        first_number = 532;
        second_number = 857.8;
        third_number = 22.9;
        double answer = first_number * second_number * third_number;
        System.out.println(answer); */

        /*for(int i=1;i<=6;i++){
            System.out.println(i+"square =" + (i*i));
        }*/
        /*for(int i=1; i<=3;i++){
            System.out.println("\\  /");
            System.out.println("/   \\");
        }
        System.out.println("+-----+"); */

        int highTemp = 5;
        for(int i= -3; i<= highTemp / 2;i++){
            System.out.print(i* 1.8 + 32 + "\n");
        }
    }
}
