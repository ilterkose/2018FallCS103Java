public class Lab2Task1 {
    public static void main(String[] args){
        /* Ilter Kose, S015555,CS103 */
        verse1();
        verse2();
        verse3();
        verse4();
        verse5();
    }

    public static void verse1() {
        System.out.println("\n My Lady d'Arbanville, why do you sleep so still? \n I'll wake you tomorrow \n And you will be my fill, yes, you will be my fill\n");
    }
    public static void verse2() {
        System.out.println(" My Lady d'Arbanville, why does it grieve me so?\n But your heart seems so silent\n Why do you breathe so low, why do you breathe so low\n");
    }
    public static void verse3() {
        System.out.println(" My Lady d'Arbanville, why do you sleep so still?\n I'll wake you tomorrow\n And you will be my fill, yes, you will be my fill\n");
    }
    public static void verse4() {
        System.out.println(" My Lady d'Arbanville, you look so cold tonight\n Your lips feel like winter\n Your skin has turned to white, your skin has turned to white\n");
    }
    public static void verse5() {
        System.out.println(" My Lady d'Arbanville, why do you sleep so still?\n I'll wake you tomorrow\n And you will be my fill, yes, you will be my fill\n");
    }
}
