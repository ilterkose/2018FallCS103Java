import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Question3 {

	public static void main(String[] args)  throws FileNotFoundException {
		Scanner input = new Scanner(new File("grades.txt"));
		
		int sum=0;		
		
		for (int i=1;i<=10;i++) {
			int grade=input.nextInt();
			sum+=grade;			
		}
		input.close();
		double avg=(double) sum/10;
		System.out.println( "Total avearage  is: "+avg );
		
	}

}
