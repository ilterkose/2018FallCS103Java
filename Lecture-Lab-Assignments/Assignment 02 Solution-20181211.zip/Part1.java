
public class Part1 {
	private static int R = 255;
	private static int G = 255;
	private static int B = 255;
	
	public static void main(String [] args) {
			print();
			convertToBlack();
			print();
			createRed();
			print();
			convertToRed();
			print();
	}
	
	public static void print() {
		System.out.println("R: " + R + " G: " + G + " B: " + B);
	}
	
	public static void convertToBlack() {
		System.out.println("Converting to black...");
		R = 0; G = 0; B = 0;
	}
	
	public static void createRed() {
		System.out.println("Creating red color...");
		int r = 255;
		int g = 0;
		int b = 0;
	}
	
	public static void convertToRed() {
		System.out.println("Converting to red...");
		R = 255;
		G = 0;
		B = 0;;
	}
}
