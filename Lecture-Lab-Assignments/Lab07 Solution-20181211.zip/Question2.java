
public class Question2 {
	private static final int MAX = 100;

	public static void main(String[] args) {
		System.out.println("Prime numbers until " + MAX);
		for (int n = 2; n <= MAX; n++) {
			if (isPrimeNumber(n)) {
				System.out.print(n + " ");
			}
		}
	}

	public static boolean isPrimeNumber(int number) {
		for (int i = 2; i < number; i++) {
			if ((number % i) == 0) {
				return false;
			}
		}
		return true;
	}
}
