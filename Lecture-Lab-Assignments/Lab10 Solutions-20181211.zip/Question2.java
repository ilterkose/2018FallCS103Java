import java.util.Scanner;

public class Question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		  Scanner input = new Scanner ( System.in ); 
	        int num; 
	        System.out.println( "Please enter a number:" );
	        num = input.nextInt();
	        input.close();
	        if (isPerfect(num) && isDivisibleBy3(num))
	        	System.out.println( num +" is a perfect number and divisible by 3." );
	        else if (isPerfect(num) &&  ! isDivisibleBy3(num))
	        	System.out.println( num +" is a perfect number but not divisible by 3." );
	        else if (!isPerfect(num) &&   isDivisibleBy3(num))
	        	System.out.println( num +" is not perfect number but it is divisible by 3." );
	        else if  (!(isPerfect(num) ||   isDivisibleBy3(num)) )
	        	System.out.println( num +" is not a perfect number and not divisible by 3." );
	        

	}

	public static boolean isPerfect(int n) {
		int sum=0;
		for (int i=1;i<n;i++) {
			if (n%i==0)
				sum+=i;
		}
		
				
		return sum==n;//Good coding style (i.e Boolean Zen)
		
		//Bad Coding style
		/*
		 * if(sum==n)
		 * 	{
		 * 	return true;
		 * 	}
		 * else
		 * 	{
		 * 	return false;
		 * 	}
		 * */
	}


	public static boolean isDivisibleBy3(int n) {
		//Good coding style (i.e Boolean Zen)
		return n%3==0;
		//Bad Coding style
		/*
		if (n%3==0)
			return true;
		else 
			return false;
			*/
	}

}
