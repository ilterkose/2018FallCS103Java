public class Exercise {

    public static void main(String[] args){
        for(int k=1 ; k<=2; k++ ){
            for (int j=6 ; j >= 2 ; j-- ){
                System.out.println(k + " * " + j + "=" + (k*j));

                }
                System.out.println();
            }
        }
}
