package Assignment3;


public class hw3 {

    public static void main(String[] args) {
    	////// Q1 /////////
    	System.out.println(calculateGaussian(3,2,1));
    	
    	////// Q2 /////////
     	System.out.println(extractNumber("Number of students in class A is:123"));
     	System.out.println(compareNumbers("Number of students in class B is:45", "Number of students in class C is:63"));
     	
     	////// Q3 /////////
        String s = "Take me home right now";
        for (int i = 0; i < s.length(); i++)
            System.out.println(moveToIndex(s, "home", i));
       
        ////// Q4 /////////
        System.out.println(replaceCharAt("ABCDEFG", 3, "**"));
        System.out.println(evaluateString("T&!F|T&!F"));
        System.out.println(evaluateString("F&!F|T&!F"));
    }

    // Q1
    public static double calculateGaussian(double x, double mean, double stddev) {
        /**
         * @params x, mean (μ), stddev (σ)
         * @return Result of Gaussian Formula given x, μ and σ
         */
        return (1 / (stddev * Math.sqrt(2 * Math.PI)))
                * (Math.pow(Math.E, -(Math.pow(x - mean, 2)) / (2 * Math.pow(stddev, 2))));
    }

    // Q2 (a)
    public static int extractNumber(String text) {
        /**
         * @param text, a formatted String that contains number after : character
         * @return extracted number from String
         */
        int dotIndex = text.indexOf(":");
        String number = text.substring(dotIndex + 1);

        return Integer.parseInt(number);
    }

    // Q2 (b)
    public static int compareNumbers(String s1, String s2) {
        /**
         * @params t1, t2 -> two formatted Strings that contain number after : character
         * @return bigger number that is extracted from Strings
         */
        int first = extractNumber(s1);
        int second = extractNumber(s2);

        if (first >= second)
            return first;
        else
            return second;
    }

    // Q3
    public static String moveToIndex(String text, String keyword, int index) {
        /**
         * @params text, keyword, index
         * @return bigger number that is extracted from Strings
         */
        int keyIndex = text.indexOf(keyword);
        if (keyIndex == -1)
            return "Not Found";
        if (keyIndex == index || (index > keyIndex && index < keyIndex + keyword.length()))
            return text;

        String before;
        String after;

        if (index > keyIndex) {
            before = text.substring(0, keyIndex) + text.substring(keyIndex + keyword.length(), index);
            after = text.substring(index, text.length());

        } 
        else { // index < keyIndex
            before = text.substring(0, index);
            after = text.substring(index, keyIndex) + text.substring(keyIndex + keyword.length(), text.length());
        }

        String modifiedText = before + keyword + after;

        return modifiedText;
    }

    // Q4
    public static char flip(char a) {
        /**
         * @param char a -> 'T' or 'F' character
         * @return return the negated value. i.e. flip('T') returns 'F'
         */
        if (a == 'T')
            return 'F';
        return 'T';
    }

    public static String replaceCharAt(String s, int pos, String c) {
        /**
         * @params string, position, character
         * @return modified version of S, that contains char C at index Pos
         */
        return s.substring(0, pos) + c + s.substring(pos + 1);
    }

    public static boolean char2bool(char c) {
        /**
         * @param char C -> 'T' or 'F'
         * @return boolean value of the char. T -> true, F -> false
         */
        if (c == 'T')
            return true;
        return false;
    }

    public static char bool2char(boolean b) {
        /**
         * @param boolean b -> true or false
         * @return char representation of boolean value of the char. true -> 'T', false -> 'F'
         */
        if (b)
            return 'T';
        return 'F';
    }
    public static String handleAndOr(String s, char operator ) {
        /**
         * @param string, operator
         * @return modified string
         */
    	int i = 0;
        while (i < s.length() - 2) {
            char a = s.charAt(i);
            char b = s.charAt(i + 1);
            char c = s.charAt(i + 2);
            if (b == operator) {
                // Handle AND operation here
                boolean value1 = char2bool(a);
                boolean value2 = char2bool(c);
                boolean result;
                if (operator == '&')
                	result = value1 && value2;
                else
                	result = value1 || value2;
                s = replaceCharAt(s, i, String.valueOf(bool2char(result)));
                s = replaceCharAt(s, i + 2, "");
                s = replaceCharAt(s, i + 1, "");
                System.out.println(s); // Print the modified expression (No ANDs) or (No ORs) 
            }
            i++;
        }
        return s;
    }
    public static boolean evaluateString(String s) {
        /**
         * @param String s -> Representing a logical expression i.e. "T&!F|T&!F"
         * @return truth value of the expression
         */

        System.out.println(s); // Print the original expression
        // We should handle operations in following order ! > & > |
        // Handle negations (!) first
        for (int i = 0; i < s.length() - 1; i++) {
            // Handle all negations in String
            if (s.charAt(i) == '!') {
                char flipped = flip(s.charAt(i + 1));
                s = replaceCharAt(s, i + 1, String.valueOf(flipped));
            }
        }
        // We are done with negations. Remove all ! signs from String.
        s = s.replace("!", "");
        System.out.println(s); // Print the modified expression (No NEGATIONS)
        // Now we should handle AND(&) operations
        s=handleAndOr(s,'&');
        
        // Handling OR operations (|)
        s=handleAndOr(s,'|');
       
        
        return char2bool(s.charAt(0));
    }

}