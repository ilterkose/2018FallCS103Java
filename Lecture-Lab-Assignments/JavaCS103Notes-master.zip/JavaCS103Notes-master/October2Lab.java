public class October2Lab {
    public static void main(String[] args){
        /* Ilter Kose,CS 103, Fall 2018, LAB01
           This program has several lines  */
        System.out.println("Benim adım \"Ilter\". \n\n Orgu orer gibi kod yazarım: \n\n 2 ters: \\\\  1 duz: / cizgi atarım.");


    }
}
