import java.util.Scanner;

public class Assignment3_Q3 {
    public static void main(String[] args){


    }
   public static String moveToIndex(String text,String keyword,int index){

        String modifiedSentence= "";



        return modifiedSentence;
    }
}
