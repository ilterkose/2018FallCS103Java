import java.util.*;
public class Question2 {
public static void main(String args[])
	{
	Scanner console = new Scanner(System.in);
	System.out.println("Enter the integer value of X");
	int X=console.nextInt();
	int sum=SumOfNumbers(X);
	double Average=AverageOfNumbers(X);
	System.out.println("Sum is "+sum+" and Average is "+Average);
	}

public static int SumOfNumbers(int x)
	{
	int result=0;
	for(int i=0;i<x;i++)
		{
			result=result+i;
		}
	return result;	
	}

public static double AverageOfNumbers(int x)
	{
	double result=SumOfNumbers(x)/(x);
	return result;
	}

}
