import java.util.Scanner;

public class Question4 {
	public static void main(String[] args) {
		String original = ""; // Objects of String class
		Scanner in = new Scanner(System.in);

		System.out.print("Enter a string to check if it is a palindrome: ");
		original = in.nextLine();
		in.close();
		original = original.toLowerCase();
		if (isPalindrome(original)) {
			System.out.println("Palindrome");
		} else {
			System.out.println("Not palindrome");
		}

	}

	public static boolean isPalindrome(String original) {
		String reverse = "";
		int length = original.length();

		for (int i = length - 1; i >= 0; i--)
			reverse = reverse + original.charAt(i);

		return original.equals(reverse);
	}
}
