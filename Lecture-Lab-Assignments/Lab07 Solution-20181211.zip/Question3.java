
public class Question3 {
	public static void main(String[] args) {
		printTriangleType(5, 7, 7);
		printTriangleType(6, 6, 6);
		printTriangleType(5, 7, 8);
		printTriangleType(2, 18, 2);

	}
	
	public static void printTriangleType(int s1, int s2, int s3) {
		
		if(
				(s1>(s2+s3))
				||(s2>(s1+s3))
				||(s3>(s1+s2))
				)//check if it ia legal triangle
		{
			System.out.println("Triangle with sides of length "+s1+" "+s2+" and "+s3+" is illegal");
		}
		else if (s1 == s2) {
	        if (s2 == s3) {
	            System.out.println("equilateral");
	        }
	    } else if (s1 == s2 || s1 == s3 || s2 == s3) {
	        System.out.println("isosceles");
	    } else {
	        System.out.println("scalene");
	    }
	}
}
