
public class Part2b {
	public static void main(String [] args) {
		printFirstLine(35);
		printSecondLine(31);
		printThirdLine();
		printSecondLine(31);
		printFirstLine(35);
	}
	
	public static void printFirstLine(int starCount) {
		for(int i = 0; i< starCount; i++) {
			System.out.print("*");
		}
		System.out.println();
	}
	
	public static void printSecondLine(int spaceCount) {
		System.out.print("**");
		for(int i = 0; i< spaceCount; i++) {
			System.out.print(" ");
		}
		System.out.println("**");
	}
	
	public static void printThirdLine() {
		System.out.print("**");
		System.out.print(" Lionel Messi & Xavi Hernandez ");
		System.out.println("**");
	}
}
