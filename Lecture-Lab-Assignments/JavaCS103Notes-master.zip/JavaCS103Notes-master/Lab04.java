public class Lab04 {


    public static void main(String[] args){
        Task_1B();
    }

    public static void Task1(){

        for(int i=0;i<=10;i++){

            System.out.println("5 * " + i + " = " + 5*i);

        }
    }

    public static void Task_1B(){

        for(int i=1;i<=5;i++){

            for(int k=1;k<=5;k++){

                System.out.println(i + "*" + k + "=" + i*k);

            }

            System.out.println();
        }
    }

    public static void method3(){


    }
}
