package assg1;

public class cylinder {
    
	public static void main(String[] args) {
	int r = 2;
    int h = 4;
   
    double pi=3.14;
    double area = 2*pi*r*r + 2*pi*r*h;
    double volume = pi*r*r + h;
    
    System.out.println("Area of cylinder = " + area);
    System.out.println("Volume of cylinder =  " + volume);
}

}